# -*- coding: utf-8 -*-
"""Read-only geometry identity mapping, compatible with IronPython 2.7.

No Ansys imports, session connection, NumPy or SciPy. All coordinates are GLOBAL
mm and areas mm2. The historic reference_geometry.json keys centroid_m/area_m2
are known mislabels for mm/mm2 in THIS audited project; do not reuse that unit
assumption for arbitrary input. Prefer explicit centroid_mm/area_mm2 fields.

source_geometry and target_geometry are lists of bodies with object_id, geo_id,
faces; every face supplies id, type, area_mm2 and centroid_mm (legacy aliases
accepted). Body names, list order, IDs, and approximate body volume are never
used as geometry evidence. Splitting/merging a required face is not guessed.
Caller must verify the imported STEP bytes/provenance and raw units separately.
Unique finite fingerprints are identity evidence, not an exact BRep comparison.

Map returns partial diagnostics on failure. NEVER apply maps unless report
['passed'] is True. A unique candidate is required inside explicit tolerances;
nearest-neighbour ranking cannot silently resolve ambiguity.
"""
from __future__ import division
import math


DEFAULT_TOLERANCES = {
    "body_centroid_mm": 0.10,
    "body_area_relative": 0.005,
    "body_area_absolute_mm2": 0.01,
    "face_centroid_mm": 0.02,
    "face_area_relative": 0.002,
    "face_area_absolute_mm2": 0.000001,
}


def _number(value):
    result = float(value)
    if math.isnan(result) or math.isinf(result):
        raise ValueError("Nonfinite geometry measure")
    return result


def _vector(value):
    if len(value) != 3:
        raise ValueError("Expected three GLOBAL coordinates")
    return [_number(x) for x in value]


def _distance(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def surface_type(value):
    value = str(value).lower()
    for fragment, result in (("bspline", "bspline"), ("bezier", "bezier"),
                             ("cylind", "cylinder"), ("plan", "plane"),
                             ("spher", "sphere"), ("tor", "torus"),
                             ("con", "cone")):
        if fragment in value:
            return result
    return value


def _face(face):
    area = _number(face["area_mm2"] if "area_mm2" in face else face["area_m2"])
    if area <= 0:
        raise ValueError("Nonpositive face area: " + str(face.get("id")))
    centroid = _vector(face["centroid_mm"] if "centroid_mm" in face else face["centroid_m"])
    return {"id": int(face["id"]), "area": area, "centroid": centroid,
            "type": surface_type(face["type"])}


def _body(body):
    faces = [_face(f) for f in body["faces"]]
    if not faces:
        raise ValueError("Body has no faces: " + str(body.get("object_id")))
    ids = [f["id"] for f in faces]
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicate face IDs in body")
    area = sum(f["area"] for f in faces)
    centroid = [sum(f["area"] * f["centroid"][i] for f in faces) / area for i in range(3)]
    return {"object_id": int(body["object_id"]), "geo_id": int(body["geo_id"]),
            "faces": faces, "area": area, "centroid": centroid}


def _cell(centroid, size):
    return tuple(int(math.floor(x / size)) for x in centroid)


def _index(faces, size):
    result = {}
    for face in faces:
        key = (face["type"],) + _cell(face["centroid"], size)
        result.setdefault(key, []).append(face)
    return result


def _candidates(source, index, tolerance):
    size = tolerance["face_centroid_mm"]
    cell = _cell(source["centroid"], size)
    hits = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                key = (source["type"], cell[0]+dx, cell[1]+dy, cell[2]+dz)
                for target in index.get(key, []):
                    distance = _distance(source["centroid"], target["centroid"])
                    delta = abs(source["area"] - target["area"])
                    allowed = tolerance["face_area_absolute_mm2"] + tolerance["face_area_relative"] * max(source["area"], target["area"])
                    if distance <= size and delta <= allowed:
                        hits.append({"target_face_id": target["id"],
                                     "centroid_distance_mm": distance,
                                     "area_absolute_error_mm2": delta,
                                     "area_relative_error": delta/max(source["area"],target["area"])})
    return hits


def map_geometry(source_geometry, target_geometry, retained_source_objids=None,
                 required_face_ids=None, tolerances=None):
    """Return old-object->new-object IDs, old-face->new-face IDs, rejectReport.

    Retained IDs refer to source metadata only, never target identities. Passing
    required_face_ids=None requests every face on retained source bodies. Target
    may contain all original bodies or only the case's retained seven/nine.
    A changed global pose/units is rejected; no unrecorded registration occurs.
    """
    tol = dict(DEFAULT_TOLERANCES)
    if tolerances:
        unknown = set(tolerances) - set(tol)
        if unknown:
            raise ValueError("Unknown mapping tolerance(s): " + str(sorted(unknown)))
        tol.update(tolerances)
    for key, value in list(tol.items()):
        tol[key] = _number(value)
        if tol[key] < 0 or (key == "face_centroid_mm" and tol[key] == 0):
            raise ValueError("Invalid mapping tolerance: " + key)
    report = {"schema": "portable-geometry-mapping/v1", "passed": False,
              "status": "rejected", "units": {"length": "mm", "area": "mm2"},
              "coordinate_frame": "unchanged_global_X_Y_Z", "tolerances": tol,
              "body_matches": [], "face_matches": [], "errors": [], "warnings": [],
              "volume_used_for_identity": False, "names_or_ID_values_used_for_identity": False,
              "policy": "Require unique geometry candidates; no nearest-choice tie breaking or face split/merge replacement"}
    errors = report["errors"]
    source = [_body(b) for b in source_geometry]
    target = [_body(b) for b in target_geometry]
    source_ids = [b["object_id"] for b in source]
    target_ids = [b["object_id"] for b in target]
    if len(set(source_ids)) != len(source_ids) or len(set(target_ids)) != len(target_ids):
        raise ValueError("Body object IDs are not unique within the input")
    retained = set(source_ids if retained_source_objids is None else [int(i) for i in retained_source_objids])
    if not retained or not retained.issubset(set(source_ids)):
        raise ValueError("Empty or unknown retained source body selection")
    source = [b for b in source if b["object_id"] in retained]
    face_owner = {}
    for body in source:
        for face in body["faces"]:
            if face["id"] in face_owner:
                raise ValueError("Source face IDs must be globally unique")
            face_owner[face["id"]] = body["object_id"]
    required = set(face_owner if required_face_ids is None else [int(i) for i in required_face_ids])
    if not required or not required.issubset(set(face_owner)):
        raise ValueError("Empty required face list or a face belongs to an excluded/unknown body")
    body_map, face_map, matched = {}, {}, {}
    used_bodies = set()
    for body in source:
        hits = []
        for candidate in target:
            distance = _distance(body["centroid"],candidate["centroid"])
            delta = abs(body["area"]-candidate["area"])
            allowed = tol["body_area_absolute_mm2"]+tol["body_area_relative"]*max(body["area"],candidate["area"])
            if distance <= tol["body_centroid_mm"] and delta <= allowed:
                hits.append((candidate,distance,delta))
        if len(hits) != 1:
            errors.append({"kind":"body_candidate_count", "source_object_id":body["object_id"],
                           "candidate_count":len(hits), "target_object_ids":[h[0]["object_id"] for h in hits]})
            continue
        candidate,distance,delta = hits[0]
        if candidate["object_id"] in used_bodies:
            errors.append({"kind":"duplicate_target_body", "source_object_id":body["object_id"],
                           "target_object_id":candidate["object_id"]})
            continue
        used_bodies.add(candidate["object_id"])
        body_map[body["object_id"]] = candidate["object_id"]
        matched[body["object_id"]] = candidate
        record = {"source_object_id":body["object_id"], "source_geo_id":body["geo_id"],
                  "target_object_id":candidate["object_id"], "target_geo_id":candidate["geo_id"],
                  "surface_centroid_distance_mm":distance, "surface_area_absolute_error_mm2":delta,
                  "source_face_count":len(body["faces"]), "target_face_count":len(candidate["faces"])}
        report["body_matches"].append(record)
        if len(body["faces"]) != len(candidate["faces"]):
            report["warnings"].append({"kind":"body_face_count_changed", "source_object_id":body["object_id"],
                                       "note":"Only independently matched required faces can pass; no full topology bijection is claimed"})
    used_faces = set()
    for body in source:
        if body["object_id"] not in matched:
            continue
        index = _index(matched[body["object_id"]]["faces"],tol["face_centroid_mm"])
        for face in body["faces"]:
            if face["id"] not in required:
                continue
            hits = _candidates(face,index,tol)
            if len(hits) != 1:
                errors.append({"kind":"face_candidate_count", "source_object_id":body["object_id"],
                               "source_face_id":face["id"], "surface_type":face["type"],
                               "candidate_count":len(hits), "candidates":hits,
                               "note":"Missing, changed, split/merged or ambiguous surface; do not apply an approximate replacement"})
                continue
            hit = hits[0]
            if hit["target_face_id"] in used_faces:
                errors.append({"kind":"duplicate_target_face", "source_face_id":face["id"], "candidate":hit})
                continue
            used_faces.add(hit["target_face_id"])
            face_map[face["id"]] = hit["target_face_id"]
            hit.update(source_face_id=face["id"], source_object_id=body["object_id"],
                       target_object_id=body_map[body["object_id"]], surface_type=face["type"])
            report["face_matches"].append(hit)
    report.update(required_body_count=len(retained), required_face_count=len(required),
                  mapped_body_count=len(body_map), mapped_face_count=len(face_map),
                  unmapped_source_face_ids=sorted(required-set(face_map)))
    report["passed"] = not errors and len(body_map)==len(retained) and len(face_map)==len(required)
    report["status"] = "unique_geometry_mapping_passed" if report["passed"] else "rejected_do_not_apply_partial_maps"
    return body_map,face_map,report


def require_mapping(source_geometry, target_geometry, retained_source_objids,
                    required_face_ids, tolerances=None):
    """Fail-closed convenience entry point for a Mechanical tree builder."""
    bodies,faces,report = map_geometry(source_geometry,target_geometry,
                                     retained_source_objids,required_face_ids,tolerances)
    if not report["passed"]:
        import json
        raise ValueError("Geometry remapping rejected: " + json.dumps(report["errors"]))
    return bodies,faces,report
