# -*- coding: utf-8 -*-
"""Run inside a NEW standalone Mechanical 2024 R2 session. Never solve.

IronPython 2.7 compatible. The receiving Mechanical release creates its own
native databases; this file does not downgrade a newer binary database.
"""
from __future__ import division
import copy
import json
import math
import os
import sys
import time
import traceback
import System


def read_json(path):
    from System.IO import File
    from System.Text import Encoding
    return json.loads(unicode(File.ReadAllText(path, Encoding.UTF8)).lstrip(u'\ufeff'))


def write_json(path, value):
    from System.IO import File
    from System.Text import Encoding
    File.WriteAllText(path, json.dumps(value, ensure_ascii=True, indent=2), Encoding.UTF8)


def runtime_identity():
    process = System.Diagnostics.Process.GetCurrentProcess()
    return {'executable': unicode(process.MainModule.FileName),
            'file_version': unicode(process.MainModule.FileVersionInfo.FileVersion),
            'product_version': unicode(process.MainModule.FileVersionInfo.ProductVersion),
            'pid': int(process.Id)}


def verify_package_assets(root):
    from System import BitConverter
    from System.IO import FileStream, FileMode, FileAccess, FileShare
    from System.Security.Cryptography import SHA256
    checksum_file = os.path.join(root, 'package_sha256.json')
    if os.path.isfile(checksum_file):
        expected = read_json(checksum_file)['files']
    else:
        expected = dict((item['package_file'], item['sha256']) for item in
                        read_json(os.path.join(root, 'transfer_manifest.json'))['source_assets'])
    for relative, digest in expected.items():
        path = os.path.join(root, relative)
        stream = FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)
        algorithm = SHA256.Create()
        try:
            actual = unicode(BitConverter.ToString(algorithm.ComputeHash(stream))).replace('-', '').lower()
        finally:
            algorithm.Dispose(); stream.Dispose()
        if actual != digest:
            raise ValueError('Package file checksum mismatch: ' + relative)
    return {'verified_files': len(expected), 'passed': True}


def selection(ids):
    from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
    if not ids:
        raise ValueError('Empty geometry selection is forbidden')
    result = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    result.Ids = list(ids)
    return result


def named(name, ids):
    result = Model.AddNamedSelection()
    result.Name = name
    result.Location = selection(ids)
    return result


def set_like(obj, key, value):
    """Set a supported property using its runtime enum/quantity type; fail closed."""
    current = getattr(obj, key)
    try:
        native_type = current.GetType()
        is_enum = native_type.IsEnum
    except AttributeError:
        is_enum = False
    if is_enum:
        converted = System.Enum.Parse(native_type, unicode(value))
    elif isinstance(current, bool):
        if not isinstance(value, bool):
            raise ValueError('Boolean property requires a Boolean: ' + key)
        converted = value
    elif isinstance(current, (int, long)):
        converted = int(value)
    elif isinstance(current, float):
        converted = float(value)
    elif hasattr(current, 'Unit') and hasattr(current, 'Value'):
        converted = Quantity(unicode(value))
    else:
        converted = value
    # Some Mechanical properties are conditionally read-only. An already equal
    # value is verified directly; an unequal read-only value still fails.
    if unicode(current) == unicode(converted):
        return
    try:
        setattr(obj, key, converted)
    except Exception as error:
        raise ValueError('Cannot set ' + key + ' from ' + unicode(current) + ' to ' +
                         unicode(converted) + ': ' + unicode(error))


def export_geometry():
    result = []
    for body in Model.Geometry.GetChildren(DataModelObjectCategory.Body, True):
        geo = body.GetGeoBody()
        result.append({'object_id': int(body.ObjectId), 'geo_id': int(geo.Id),
                       'name': unicode(body.Name), 'faces': [
            {'id': int(face.Id), 'type': unicode(face.SurfaceType),
             'area_mm2': float(face.Area), 'centroid_mm': [float(x) for x in face.Centroid]}
            for face in geo.Faces]})
    return result


def needed_faces(study, old_body_geoids):
    result = set(int(x) for x in study['fixed_face_ids'])
    for contact in study['contacts']:
        result.update(contact['source']); result.update(contact['target'])
    for force in study['forces']:
        result.update(force['face_ids'])
    for joint in study['native_joints']:
        result.update(joint['ReferenceLocation']); result.update(joint['MobileLocation'])
    for beam in study.get('beams', []):
        result.update(beam['reference_face_ids']); result.update(beam['mobile_face_ids'])
    for control in study['mesh_children']:
        for entity_id in control['location']:
            if entity_id not in old_body_geoids:
                result.add(int(entity_id))
    return sorted(result)


def match_geometry(reference, target, study, outdir):
    from face_mapper_27 import map_geometry
    retained = [int(row['object_id']) for row in study['bodies']]
    old_geoids = set(int(body['geo_id']) for body in reference)
    required = needed_faces(study, old_geoids)
    attempts, passed = [], []
    # GeoData units can differ by release. Only standard m/mm conversions are
    # considered, and an entire unique body+face match must verify the choice.
    for factor in (1.0, 1000.0, .001):
        normalized = copy.deepcopy(target)
        for body in normalized:
            for face in body['faces']:
                face['area_mm2'] *= factor * factor
                face['centroid_mm'] = [x * factor for x in face['centroid_mm']]
        body_map, face_map, report = map_geometry(reference, normalized, retained, required)
        report['raw_GeoData_length_to_mm_factor'] = factor
        attempts.append(report)
        if report['passed']:
            passed.append((body_map, face_map, report))
    write_json(os.path.join(outdir, study['id'] + '_geometry_mapping.json'),
               {'attempts': attempts, 'uniquely_verified_unit_interpretations': len(passed)})
    if len(passed) != 1:
        raise ValueError('Geometry identity was not uniquely verified; see geometry_mapping.json. '
                         'No contact, load or mesh selection has been applied.')
    body_map, face_map, report = passed[0]
    target_by_id = dict((row['object_id'], row) for row in target)
    old_to_new_geo = dict((int(row['geo_id']), target_by_id[body_map[int(row['object_id'])]]['geo_id'])
                         for row in study['bodies'])
    return body_map, face_map, old_to_new_geo, report


def build_study(root, study, reference, outdir, progress):
    import Ansys
    from Ansys.Mechanical.DataModel.Enums import (
        ContactType, ContactFormulation, JointScopingType, JointType, LoadBehavior,
        JointSolverElementType, ElementOrder, LoadDefineBy, SolverType,
        AutomaticTimeStepping, WeakSpringsType, TimePointsOptions)
    from Ansys.ACT.Automation.Mechanical import ArchiveSettings

    project = ExtAPI.DataModel.Project
    project.New()
    ExtAPI.Application.ActiveUnitSystem = MechanicalUnitSystem.StandardNMM
    project.Name = 'X1_' + study['id'] + '_Preprocessing'
    progress('importing_' + study['id'])
    importer = Model.GeometryImportGroup.AddGeometryImport()
    preferences = Ansys.ACT.Mechanical.Utilities.GeometryImportPreferences()
    preferences.ProcessNamedSelections = False
    preferences.ProcessMaterialProperties = False
    preferences.ProcessCoordinateSystems = False
    importer.Import(os.path.join(root, 'data', study['geometry_file']),
                    Ansys.Mechanical.DataModel.Enums.GeometryImportPreference.Format.Automatic,
                    preferences)
    target = export_geometry()
    body_map, face_map, body_geo_map, mapping_report = match_geometry(reference, target, study, outdir)
    progress('geometry_matched_' + study['id'])

    def faces(ids):
        return [face_map[int(value)] for value in ids]

    def entities(ids):
        return [body_geo_map[int(value)] if int(value) in body_geo_map else face_map[int(value)]
                for value in ids]

    material_settings = Ansys.Mechanical.Materials.ImportSettings()
    material_settings.Replace = True
    Model.Materials.Import(os.path.join(root, 'data', study['material_file']),
        Ansys.Mechanical.DataModel.MechanicalEnums.Materials.ImportFormat.Automatic,
        material_settings)
    assigned = dict((body_map[int(row['object_id'])], row) for row in study['bodies'])
    for body in Model.Geometry.GetChildren(DataModelObjectCategory.Body, True):
        row = assigned.get(int(body.ObjectId))
        body.Suppressed = row is None
        if row:
            body.Name = 'Body_' + row['name']
            body.Material = row['mechanical_material_name']
            named(row['name'], [int(body.GetGeoBody().Id)])
        else:
            body.Name = 'Excluded_' + str(body.ObjectId)
    if Model.Connections is None:
        Model.AddConnections()
    # The current project was just created by this function; remove importer
    # defaults so only the six verified source contact pairs participate.
    for old in list(Model.Connections.GetChildren(DataModelObjectCategory.ContactRegion, True)):
        old.Delete()
    contact_rows, contact_objects = [], []
    native_contact_by_scope = dict(((tuple(sorted(row['SourceLocation'])),
                                     tuple(sorted(row['TargetLocation']))), row)
                                   for row in study['native_contact_details'])
    for row in study['contacts']:
        native = native_contact_by_scope[(tuple(sorted(row['source'])), tuple(sorted(row['target'])))]
        contact = Model.Connections.AddContactRegion()
        contact.Name = native['name']
        contact.SourceLocation = selection(faces(row['source']))
        contact.TargetLocation = selection(faces(row['target']))
        contact.ContactType = getattr(ContactType, row['type'])
        contact.ContactFormulation = getattr(ContactFormulation, row['formulation'])
        for key in ('Behavior', 'SmallSliding', 'UpdateStiffness', 'InterfaceTreatment',
                    'DetectionMethod', 'PinballRegion'):
            if key in native:
                set_like(contact, key, native[key])
        contact_objects.append(contact)
        contact_rows.append({'name': unicode(contact.Name), 'type': unicode(contact.ContactType),
            'formulation': unicode(contact.ContactFormulation),
            'source': list(contact.SourceLocation.Ids), 'target': list(contact.TargetLocation.Ids)})
    joint_rows = []
    for row in study['native_joints']:
        joint = Model.Connections.AddJoint()
        joint.Name = row['name']
        joint.ConnectionType = getattr(JointScopingType, row['ConnectionType'])
        joint.Type = getattr(JointType, row['Type'])
        for key in ('ReferenceAppliedBy', 'MobileAppliedBy'):
            if key in row:
                set_like(joint, key, row[key])
        joint.ReferenceLocation = selection(faces(row['ReferenceLocation']))
        joint.MobileLocation = selection(faces(row['MobileLocation']))
        joint.ReferenceBehavior = getattr(LoadBehavior, row['ReferenceBehavior'])
        joint.MobileBehavior = getattr(LoadBehavior, row['MobileBehavior'])
        joint.SolverElementType = getattr(JointSolverElementType, row['SolverElementType'])
        joint_rows.append({'name': unicode(joint.Name), 'type': unicode(joint.Type),
            'reference_behavior': unicode(joint.ReferenceBehavior),
            'mobile_behavior': unicode(joint.MobileBehavior),
            'reference_applied_by': unicode(joint.ReferenceAppliedBy),
            'mobile_applied_by': unicode(joint.MobileAppliedBy)})
    beam_rows = []
    if study.get('beams'):
        beam_namespace = dict(globals())
        eval(compile(open(os.path.join(root, 'beam_helper.py')).read(), 'beam_helper.py', 'exec'),
             beam_namespace, beam_namespace)
        for row in study['beams']:
            spec = dict(row)
            spec['reference_face_ids'] = faces(row['reference_face_ids'])
            spec['mobile_face_ids'] = faces(row['mobile_face_ids'])
            beam = beam_namespace['create_body_body_beam'](spec)
            beam_rows.append({'name': unicode(beam.Name), 'radius_mm': float(beam.Radius.Value),
                'material': unicode(beam.Material), 'reference_behavior': unicode(beam.ReferenceBehavior),
                'mobile_behavior': unicode(beam.MobileBehavior),
                'reference_point_mm': [float(getattr(beam,'Reference'+axis+'Coordinate').Value) for axis in ('X','Y','Z')],
                'mobile_point_mm': [float(getattr(beam,'Mobile'+axis+'Coordinate').Value) for axis in ('X','Y','Z')],
                'reference_applied_by': unicode(beam.ReferenceAppliedBy),
                'mobile_applied_by': unicode(beam.MobileAppliedBy),
                'reference_coordinate_system': unicode(beam.ReferenceCoordinateSystem.Name),
                'mobile_coordinate_system': unicode(beam.MobileCoordinateSystem.Name),
                'reference': list(beam.ReferenceLocation.Ids), 'mobile': list(beam.MobileLocation.Ids)})

    mesh = Model.Mesh
    # Unlock manual sizing before assigning it. Curvature-related controls can
    # be read-only while curvature capture is disabled on a clean installation.
    # No mesh is generated while temporarily enabling this control.
    set_like(mesh, 'UseAdaptiveSizing', False)
    set_like(mesh, 'CaptureCurvature', True)
    for key in ('ElementOrder', 'ElementSize', 'MinimumSize', 'CurvatureNormalAngle', 'GrowthRate'):
        set_like(mesh, key, study['native_mesh'][key])
    for key in ('CaptureProximity', 'CaptureCurvature', 'UseAdaptiveSizing'):
        set_like(mesh, key, study['native_mesh'][key])
    mesh_rows = []
    for row in study['mesh_children']:
        if row['category'] != 'Sizing':
            raise ValueError('Unsupported source mesh control category: ' + row['category'])
        control = mesh.AddSizing()
        control.Name = row['name']
        control.Location = selection(entities(row['location']))
        for key in ('Type', 'ElementSize', 'Behavior'):
            if key in row:
                set_like(control, key, row[key])
        control.Suppressed = bool(row['suppressed'])
        mesh_rows.append({'name': unicode(control.Name), 'size': unicode(control.ElementSize),
                         'behavior': unicode(control.Behavior), 'location': list(control.Location.Ids)})

    analysis = Model.AddStaticStructuralAnalysis()
    analysis.Name = study['id'] + '_Static_Preprocessing'
    support_ids = faces(study['fixed_face_ids'])
    named('Knee_Fix', support_ids)
    support = analysis.AddFixedSupport()
    support.Name = 'Knee_Housing_Equivalent_Fixed'
    support.Location = selection(support_ids)
    forces = []
    for row in study['forces']:
        force = analysis.AddForce()
        force.Name = row['name']
        force.Location = selection(faces(row['face_ids']))
        force.DefineBy = LoadDefineBy.Components
        forces.append((force, row['fraction']))
    settings = analysis.AnalysisSettings
    settings.SolverType = SolverType.Direct
    # Preserve the native GUI controls. Effective APDL NSUB may be narrower
    # when ProgramControlled determines the source model is linear.
    native_settings = study['native_analysis_settings']
    settings.AutomaticTimeStepping = getattr(AutomaticTimeStepping, native_settings['AutomaticTimeStepping'])
    for key in ('InitialSubsteps', 'MinimumSubsteps', 'MaximumSubsteps', 'NumberOfSteps'):
        set_like(settings, key, int(native_settings[key]))
    for key in ('LargeDeflection', 'WeakSprings', 'StoreResultsAt', 'GeneralMiscellaneous', 'InertiaRelief'):
        set_like(settings, key, native_settings[key])
    settings.SetStepEndTime(1, Quantity(str(study['end_time_s']) + ' [s]'))
    command = analysis.AddCommandSnippet()
    command.Name = 'Source_Shape_Check_And_Memory_Policy'
    progress('objects_created_' + study['id'])
    expected = {'bodies': len(study['bodies']), 'contacts': 6,
                'joints': len(study['native_joints']), 'beams': len(study.get('beams', [])),
                'mesh_controls': len(study['mesh_children'])}
    actual = {'bodies': sum(not body.Suppressed for body in Model.Geometry.GetChildren(DataModelObjectCategory.Body, True)),
              'contacts': len(contact_rows), 'joints': len(joint_rows), 'beams': len(beam_rows),
              'mesh_controls': len(mesh_rows)}
    if actual != expected:
        raise ValueError('Preprocessor object count mismatch: ' + json.dumps(actual))
    created = []
    for load in study['loads_N']:
        for force, fraction in forces:
            force.XComponent.Output.DiscreteValues = [Quantity('0 [N]')]
            force.YComponent.Output.DiscreteValues = [Quantity(str(-load * fraction) + ' [N]')]
            force.ZComponent.Output.DiscreteValues = [Quantity('0 [N]')]
        mode = study['memory_modes'][str(load)]
        command.Input = ('FINISH\n/PREP7\nSHPP,ON\nCHECK\nFINISH\n/SOLU\n'
                         'DSPOPTION,,' + mode + '\n')
        stem = study['id'] + '_' + str(load) + '_preprocess'
        database = os.path.join(outdir, stem + '.mechdb')
        archive = os.path.join(outdir, stem + '.mechpz')
        project.SaveAs(database, True)
        archive_settings = ArchiveSettings(False, False)
        if archive_settings.IncludeResultAndSolutionFiles or archive_settings.IncludeUserFiles:
            raise ValueError('Preprocessing archive must exclude solution and user files')
        project.Archive(archive, True, archive_settings)
        force_rows = [{'name': unicode(force.Name), 'xyz_N': [
                float(force.XComponent.Output.DiscreteValues[0].Value),
                float(force.YComponent.Output.DiscreteValues[0].Value),
                float(force.ZComponent.Output.DiscreteValues[0].Value)],
                       'face_ids': list(force.Location.Ids)} for force, fraction in forces]
        if abs(sum(row['xyz_N'][1] for row in force_rows) + load) > 1e-8:
            raise ValueError('Total force verification failed')
        # No mesh generation or solution call exists anywhere in this builder.
        md = ExtAPI.DataModel.MeshDataByName('Global')
        nodes = len(list(md.NodeIds))
        elements = len(list(md.ElementIds))
        if nodes or elements:
            raise ValueError('Unexpected generated mesh in CAD-preprocessor rebuild')
        record = {'study': study['id'], 'total_load_N': load, 'runtime': runtime_identity(),
            'native_object_counts': actual, 'forces': force_rows, 'contacts': contact_rows,
            'joints': joint_rows, 'beams': beam_rows, 'mesh_controls': mesh_rows,
            'mapped_faces': mapping_report['mapped_face_count'], 'geometry_mapping_passed': True,
            'native_analysis_settings': dict((key, unicode(getattr(settings, key)))
                                             for key in native_settings),
            'memory_mode': mode, 'solution_status': unicode(analysis.Solution.Status),
            'mesh_nodes': nodes, 'mesh_elements': elements, 'solve_called': False,
            'include_results_and_solution_files': False, 'database': database, 'archive': archive,
            'assumptions': study['assumptions']}
        write_json(os.path.join(outdir, stem + '_verification.json'), record)
        created.append(record)
        progress('saved_' + stem)
    return created


def rebuild_all(package_root, output_root=None, allow_validation_runtime=False, studies_to_build=None):
    root = os.path.abspath(package_root)
    if not os.path.isfile(os.path.join(root, 'transfer_manifest.json')):
        raise ValueError('The complete portable package root is required')
    asset_integrity = verify_package_assets(root)
    runtime = runtime_identity()
    is_242 = runtime['product_version'].strip().startswith('24.2')
    if not is_242 and not allow_validation_runtime:
        raise ValueError('Run with Mechanical 2024 R2 (v242), not ' + runtime['executable'])
    existing = list(Model.Geometry.GetChildren(DataModelObjectCategory.Body, True))
    if existing or len(Model.Analyses):
        raise ValueError('Start a new, empty standalone Mechanical session. Existing models are never cleared.')
    if root not in sys.path:
        sys.path.insert(0, root)
    studies = read_json(os.path.join(root, 'data', 'studies.json'))
    reference = read_json(os.path.join(root, 'data', 'reference_geometry.json'))
    if output_root is None:
        output_root = os.path.join(root, 'generated_' + time.strftime('%Y%m%d_%H%M%S'))
    if os.path.exists(output_root):
        raise ValueError('Output directory already exists; choose a new directory')
    os.makedirs(output_root)
    events = []

    def progress(stage):
        events.append({'stage': stage, 'time_unix': time.time()})
        write_json(os.path.join(output_root, 'progress.json'), {'events': events, 'runtime': runtime})

    result = {'runtime': runtime, 'target_242_runtime': is_242, 'asset_integrity': asset_integrity, 'outputs': [],
              'mesh_generated': False, 'solve_called': False, 'complete': False}
    try:
        for study_id in (studies_to_build or ['S01', 'C01']):
            result['outputs'].extend(build_study(root, studies[study_id], reference, output_root, progress))
        result['complete'] = True
        progress('complete')
    except Exception:
        result['error'] = traceback.format_exc()
        progress('failed')
        write_json(os.path.join(output_root, 'build_verification.json'), result)
        raise
    write_json(os.path.join(output_root, 'build_verification.json'), result)
    return result
