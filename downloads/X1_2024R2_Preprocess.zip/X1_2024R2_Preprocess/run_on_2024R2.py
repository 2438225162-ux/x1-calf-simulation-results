# -*- coding: utf-8 -*-
"""Mechanical command-line entry point. Invoked by Build_2024R2.cmd."""
import json
import os
import sys
import traceback
import System


def package_root():
    candidates = []
    if '__file__' in globals():
        candidates.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        values = list(args)
        candidates.extend(values)
    except NameError:
        pass
    command = [unicode(x) for x in System.Environment.GetCommandLineArgs()]
    for index, item in enumerate(command[:-1]):
        if item.lower() == '-script':
            candidates.append(os.path.dirname(os.path.abspath(command[index+1])))
        elif item.lower() == '-scriptargs':
            candidates.append(command[index+1])
    for candidate in candidates:
        if os.path.isfile(os.path.join(candidate, 'transfer_manifest.json')):
            return os.path.abspath(candidate)
    raise ValueError('Cannot locate complete package. Run Build_2024R2.cmd from the extracted package.')


root = package_root()
scope = dict(globals())
source = os.path.join(root, 'rebuild_preprocessors.py')
try:
    eval(compile(open(source, 'rb').read(), source, 'exec'), scope, scope)
    scope['write_json'](os.path.join(root, 'latest_build.json'), {'complete': False, 'stage': 'starting'})
    result = scope['rebuild_all'](root)
    scope['write_json'](os.path.join(root, 'latest_build.json'), result)
    print('SUCCESS: four preprocessing archives created with the receiving Mechanical release.')
except Exception:
    from System.IO import File
    from System.Text import Encoding
    File.WriteAllText(os.path.join(root, 'BUILD_FAILED.txt'), traceback.format_exc(), Encoding.UTF8)
    File.WriteAllText(os.path.join(root, 'latest_build.json'),
                      json.dumps({'complete': False, 'error': traceback.format_exc()}), Encoding.UTF8)
    raise
