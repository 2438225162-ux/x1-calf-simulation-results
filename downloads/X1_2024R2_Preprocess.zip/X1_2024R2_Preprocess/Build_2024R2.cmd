@echo off
setlocal
title X1 - Build preprocessing models in ANSYS 2024 R2
set "X1_ANSYS242_ROOT=%AWP_ROOT242%"
if not defined X1_ANSYS242_ROOT if exist "C:\Program Files\ANSYS Inc\v242\aisol\bin\winx64\AnsysWBU.exe" set "X1_ANSYS242_ROOT=C:\Program Files\ANSYS Inc\v242"
if not defined X1_ANSYS242_ROOT if exist "D:\Program Files\ANSYS Inc\v242\aisol\bin\winx64\AnsysWBU.exe" set "X1_ANSYS242_ROOT=D:\Program Files\ANSYS Inc\v242"
if not defined X1_ANSYS242_ROOT set /p "X1_ANSYS242_ROOT=Enter the ANSYS 2024 R2 install root (ending in v242): "
if not exist "%X1_ANSYS242_ROOT%\aisol\bin\winx64\AnsysWBU.exe" (
  echo Mechanical 2024 R2 was not found. SpaceClaim alone is insufficient.
  pause
  exit /b 1
)
echo Creating CAD preprocessing models. No mesh generation and no solve.
echo Output: generated_YYYYMMDD_HHMMSS folder beside this command file.
"%X1_ANSYS242_ROOT%\aisol\bin\winx64\AnsysWBU.exe" -DSApplet -AppModeMech -b -script "%~dp0run_on_2024R2.py" -ScriptArgs "%~dp0."
if errorlevel 1 (
  echo Build did not complete. Check BUILD_FAILED.txt and generated_...\build_verification.json.
  pause
  exit /b 1
)
if exist "%~dp0BUILD_FAILED.txt" (
  echo A failure report exists. Check its timestamp before assuming success.
) else (
  echo Check latest_build.json for complete=true and target_242_runtime=true.
  echo Open a generated .mechdb or .mechpz in Mechanical 2024 R2.
)
pause
endlocal
