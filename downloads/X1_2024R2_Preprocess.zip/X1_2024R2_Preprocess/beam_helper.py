# Mechanical IronPython helper. Import/exec only defines functions; no objects are created.
import math
from Ansys.ACT.Interfaces.Common import SelectionTypeEnum
from Ansys.Mechanical.DataModel.Enums import (SpringScopingType, CrossSectionType,
    RemoteApplicationType, LoadBehavior, ProbeDisplayFilter, LocationDefinitionMethod)

def _selection(face_ids):
    if not face_ids:
        raise ValueError('Explicit local attachment face IDs are required')
    selection = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    selection.Ids = list(face_ids)
    return selection

def create_body_body_beam(spec, model=None):
    """Create a circular beam only after all mechanical inputs are provided.

    Required spec keys: name, reference_face_ids, mobile_face_ids,
    reference_point_mm, mobile_point_mm, radius_mm, material_name,
    reference_behavior, mobile_behavior, dimensions_source, material_source.
    Positions are global XYZ. Radius is the declared effective shank/section
    radius, not a hole radius. No bolt pretension object is created.
    """
    if model is None:
        model = Model
    required = ['name', 'reference_face_ids', 'mobile_face_ids', 'reference_point_mm',
                'mobile_point_mm', 'radius_mm', 'material_name', 'reference_behavior',
                'mobile_behavior', 'dimensions_source', 'material_source']
    missing = [key for key in required if spec.get(key) is None or spec.get(key) == '']
    if missing:
        raise ValueError('Beam remains pending: missing ' + ', '.join(missing))
    radius = float(spec['radius_mm'])
    if math.isnan(radius) or math.isinf(radius) or radius <= 0:
        raise ValueError('Confirmed positive effective beam radius is required')
    start, end = spec['reference_point_mm'], spec['mobile_point_mm']
    if len(start) != 3 or len(end) != 3:
        raise ValueError('Beam endpoints require global XYZ triples')
    length = math.sqrt(sum((float(end[i])-float(start[i]))**2 for i in range(3)))
    if math.isnan(length) or math.isinf(length) or length <= 1e-8:
        raise ValueError('Beam endpoints coincide; confirmed nonzero effective grip length is required')
    material_names = [m.Name for m in model.Materials.Children]
    if spec['material_name'] not in material_names:
        raise ValueError('Confirmed beam material is not imported: ' + spec['material_name'])
    allowed = ['Rigid', 'Deformable']
    if spec['reference_behavior'] not in allowed or spec['mobile_behavior'] not in allowed:
        raise ValueError('Attachment behavior must be explicit Rigid or Deformable; Beam spiders need additional radius/material inputs')
    reference = _selection(spec['reference_face_ids'])
    mobile = _selection(spec['mobile_face_ids'])
    # Face scoping is set first because it can reset endpoint coordinates.
    connections = model.Connections
    if connections is None:
        connections = model.AddConnections()
    beam = connections.AddBeam()
    beam.Name = spec['name']
    beam.Scope = SpringScopingType.BodyToBody
    # v261 runtime reflection confirms CrossSection is read-only. AddBeam
    # creates the circular connection section; validate instead of assigning.
    if beam.CrossSection != CrossSectionType.Circular:
        beam.Delete()
        raise ValueError('AddBeam did not create a circular section')
    beam.Material = spec['material_name']
    beam.Radius = Quantity(str(radius) + ' [mm]')
    beam.ReferenceAppliedBy = RemoteApplicationType.RemoteAttachment
    beam.MobileAppliedBy = RemoteApplicationType.RemoteAttachment
    beam.ReferenceLocation = reference
    beam.MobileLocation = mobile
    beam.ReferenceBehavior = getattr(LoadBehavior, spec['reference_behavior'])
    beam.MobileBehavior = getattr(LoadBehavior, spec['mobile_behavior'])
    global_cs = model.CoordinateSystems.Children[0]
    beam.ReferenceCoordinateSystem = global_cs
    beam.MobileCoordinateSystem = global_cs
    for prefix, point in [('Reference', start), ('Mobile', end)]:
        for axis, value in zip(['X', 'Y', 'Z'], point):
            setattr(beam, prefix + axis + 'Coordinate', Quantity(str(float(value)) + ' [mm]'))
    # Optional radius limits only the remote attachment's node influence; this
    # parameter does not specify a physical bolt head or washer diameter.
    for key, api in [('reference_attachment_radius_mm', 'ReferencePinballRegion'),
                     ('mobile_attachment_radius_mm', 'MobilePinballRegion')]:
        if spec.get(key) is not None:
            value = float(spec[key])
            if value <= 0 or math.isnan(value) or math.isinf(value):
                beam.Delete()
                raise ValueError('Invalid explicitly supplied attachment influence radius')
            setattr(beam, api, Quantity(str(value) + ' [mm]'))
    return beam

