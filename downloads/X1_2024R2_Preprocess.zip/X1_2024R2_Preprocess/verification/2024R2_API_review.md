# 2024 R2 原生前处理转移核查

核查日期：2026-10-15。只读检查本机安装、官方 API stubs 和 Ansys 官方资料；未启动 ANSYS，未修改原工程。本文没有声称实际运行过 Mechanical 2024 R2。

## 可交付物及边界

- 当前最可靠路线：把中性 STEP、材料 XML、前处理定义及几何匹配信息带到 **Mechanical 2024 R2**，在该版本重新创建原生 Mechanical 对象，再用该版本保存和归档。可保留材料、实体抑制、接触、关节/螺栓梁、命名选择、网格控制、载荷和分析设置；不生成网格、不求解、不打包结果即可。
- 2026 R1 中执行 `SaveAs` 或取消归档的结果选项，只会生成运行版本的工程，不会把数据库降级为 2024 R2。换扩展名、手工改版本标签也不是转换。
- 本机 `D:\Program Files\ANSYS Inc\v242` 目前只有 `scdm` 目录，没有本次核查所需的 Mechanical、MAPDL 或 Workbench 242 可执行程序。因此 242 API 静态核查与 261 试跑不能替代 242 实际重建、保存和重新打开验证。
- 重建应校验实体数、体积/质心/包围盒，面匹配应按几何签名核对，不能假定跨版本导入后的几何 ID 恒定。无法唯一匹配的作用面应停止并报告，不得静默扩大作用域。

## 2024 R2 本地 API 存在性证据

相对路径前缀：`.venv/Lib/site-packages/ansys/mechanical/stubs/v242/`。

| 所需对象 | 242 接口核查 | 本地证据 |
|---|---|---|
| 导入 CAD | `Model.GeometryImportGroup.AddGeometryImport()`；`GeometryImport.Import(uri, format, preferences)` | `Ansys/ACT/Automation/Mechanical/__init__.py` 13428、13845 行 |
| 导入材料 | `Model.Materials.Import(materialURI, format, settings)` | 同文件 35227 行 |
| 材料导入设置 | `Ansys.Mechanical.Materials.ImportSettings()` 无参构造，`Replace`、`Filter` 可设置 | `Ansys/Mechanical/Materials/__init__.py` 8、11、31、50 行 |
| 材料格式枚举 | `Ansys.Mechanical.DataModel.MechanicalEnums.Materials.ImportFormat.Automatic` | `Ansys/Mechanical/DataModel/MechanicalEnums/Materials/__init__.py` |
| 创建螺栓梁 | `Connections.AddBeam()` | `Ansys/ACT/Automation/Mechanical/Connections/__init__.py` 9378 行 |
| 梁作用域/截面 | `Scope` 可设置；`CrossSection` **只读**，应检查默认 Circular，不要赋值 | 同文件 2181、2244 行 |
| 梁参数 | `Material`、`Radius`、`ReferenceLocation`、`MobileLocation`、两端 Behavior、CoordinateSystem、XYZCoordinate、PinballRegion 均有 setter | 同文件 `Beam` 类 1930–2797 行 |
| 梁元素 | `BeamElementAPDLName` 有 setter；是否需要显式设置需目标运行时核实 | 同文件 1957–1968 行 |
| 独立 Mechanical 保存 | `Project.SaveAs(filePath, overwrite)` | `Ansys/ACT/Automation/Mechanical/__init__.py` 71499 行 |
| 独立 Mechanical 归档 | `Project.Archive(archivePath, overwrite, settings)` | 同文件 71511 行 |
| 归档不带结果/用户文件 | `ArchiveSettings(False, False)`；构造顺序是 includeResultAndSolutionFiles、includeUserFiles | 同文件 19–68 行 |

材料导入可采用显式三参，减少对未展示的默认参数的依赖：

```python
iset = Ansys.Mechanical.Materials.ImportSettings()
iset.Replace = True
Model.Materials.Import(
    material_xml,
    Ansys.Mechanical.DataModel.MechanicalEnums.Materials.ImportFormat.Automatic,
    iset)
```

注意：251/261 stubs 同样只列三参，但既有 261 代码单参调用成功。因此不能依据 stubs 单独判定 242 单参调用失败；API 存在性检查不是目标版本运行测试。

保存示意（需在独立 Mechanical 2024 R2 内执行，而非把 261 数据库伪装成 242）：

```python
project = ExtAPI.DataModel.Project
project.SaveAs(output_mechdb, True)
opts = Ansys.ACT.Automation.Mechanical.ArchiveSettings(False, False)
project.Archive(output_mechpz, True, opts)
```

## 为什么不把 CDB 当成同等 CAD 前处理工程

2024 R2 External Model 官方文档支持 MAPDL **Blocked** CDB，推荐在 PREP7 用 `CDWRITE,DB` 生成。它导入网格并合成用于 Mechanical 的几何，而非恢复原 CAD B-rep、CAD 可编辑关系或原网格控制树。官方允许导入接触、边界条件、截面、命名选择及远程连接等多种有限元数据，但仅限源文件实际包含、目标导入器支持的数据；不能承诺原始关节/梁/载荷对象及命名一一还原。导入器不执行任意循环脚本，也不支持 CDB 中的 `/INPUT`、`CDREAD` 模型组装。单位体系要明确指定。

因此 CDB 可作保留已有有限元模型的备份或复核路线；本次用户需要查看和编辑原生前处理、也不需要已有网格与结果时，中性 CAD + 242 内重建更符合需求。

## 官方来源

1. [Mechanical 2024 R2 API](https://scripting.mechanical.docs.pyansys.com/version/stable/api/ansys/mechanical/stubs/v242/index.html)
2. [242 Materials.Import](https://scripting.mechanical.docs.pyansys.com/version/stable/api/ansys/mechanical/stubs/v242/Ansys/ACT/Automation/Mechanical/Materials.html)
3. [242 Beam 属性](https://scripting.mechanical.docs.pyansys.com/version/stable/api/ansys/mechanical/stubs/v242/Ansys/ACT/Automation/Mechanical/Connections/Beam.html)
4. [242 Project 保存和归档](https://scripting.mechanical.docs.pyansys.com/version/stable/api/ansys/mechanical/stubs/v242/Ansys/ACT/Automation/Mechanical/Project.html)
5. [242 External Model：Blocked CDB、支持数据和限制](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/wb2_help/wb2h_ModelLoadapp.html)
6. [242 在独立 Mechanical 内导入 CAD / 外部网格](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/wb_sim/ds_Attach_Geometry_mech.html)
7. [242 File Tab：保存、归档及可选数据](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/wb_sim/ds_menu_file.html)
8. [Ansys 托管论坛：Workbench 不能另存为早期版本](https://innovationspace.ansys.com/forum/forums/topic/save-a-project-in-an-earlier-version/)（补充资料；API SaveAs/Archive 本身也没有目标版本参数）
