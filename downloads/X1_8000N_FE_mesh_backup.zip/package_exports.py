"""Package only the CDB review data, omitting duplicate input decks/results."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
bundle = HERE.parent / "X1_8000N_FE_mesh_backup.zip"
paths = [HERE / "README_网格备用包.md", HERE / "verification.json",
         HERE / "export_fe_only.py", HERE / "verify_exports.py", Path(__file__)]
for study in ["S01", "C01"]:
    case = HERE / study
    verification = json.loads((case / "verification.json").read_text(encoding="utf-8"))
    assert verification["passed"]
    paths += [case / (study + "_8000_FE.CDB"),
              case / (study + "_8000_APPLIED_LOADS.txt"),
              case / "verification.json", case / "static_gate.json", case / "run.json",
              case / "model_counts.txt", case / "element_family_counts.txt",
              case / "constraint_node_counts.txt", case / "export.out",
              case / (study.lower() + "_fe_export.err")]
paths = sorted(set(paths))
assert all(p.is_file() and p.resolve().is_relative_to(HERE.resolve()) for p in paths)
with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in paths:
        z.write(path, path.relative_to(HERE).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert not any(name.lower().endswith((".rst", ".rth", ".db", ".inp")) for name in z.namelist())
    count = len(z.infolist())
h = hashlib.sha256()
with bundle.open("rb") as f:
    for b in iter(lambda: f.read(4 * 1024 * 1024), b""):
        h.update(b)
result = {"path": str(bundle), "bytes": bundle.stat().st_size,
          "sha256": h.hexdigest(), "entries": count, "zip_crc_test_passed": True,
          "includes_results": False, "actual_2024R2_import_verified": False}
(HERE / "package.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result), flush=True)
