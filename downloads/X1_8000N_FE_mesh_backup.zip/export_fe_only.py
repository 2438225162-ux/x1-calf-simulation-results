"""Export existing MAPDL preprocessing decks without running a solver.

Only task-owned output directories are written. Original ds.dat files are read-only.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
EXE = Path(r"D:\Program Files\ANSYS Inc\v261\ansys\bin\winx64\ANSYS261.exe")
MARKER = b"! *********** WB SOLVE COMMAND ***********"
SOURCES = {"S01": ROOT / "S01_standing/solver_8000/ds.dat",
           "C01": ROOT / "C01_sleeve/solver_8000/ds.dat"}
COMMAND = re.compile(rb"(?mi)(?:^[ \t]*|(?<=\$)[ \t]*)([a-z/*][a-z0-9_/*]*)(?=[, \t\r\n]|$)")
ALLOWED_SOURCE = set("""/BATCH /CONFIG *GET /TITLE /COM *DIM /UNITS /NOPR /WB
 /PREP7 SHPP /NOLIST ETCON LOCAL CSYS ESYS NBLOCK ET MAT EBLOCK SECNUM TOFFST TREF
 MP *SET R KEYO RMOD NSEL ESEL CM CMBLOCK /GOLIST CMSEL D TYPE REAL TSHAPE EN
 NROT SECTYPE SECJOINT KEYOP /GST FINI /GO /SOLU ANTYPE NEQIT PRED EQSL CNTR
 NLDIAG RESCONTROL NSLE SFE /GOPR NSUB TIME OUTRES FINISH CHECK BCSOPTION
 DSPOPTION SECDATA SECOFFSET AUTOTS""".split())
ALLOWED_ADDED = set("""ALLSEL CDWRITE *CFOPEN *VWRITE *CFCLOS ETLIST MPLIST
 DLIST SFELIST /EXIT""".split())


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def gate(data, allowed):
    commands = collections.Counter()
    bad = []
    for match in COMMAND.finditer(data):
        cmd = match.group(1).decode("ascii").upper()
        end = data.find(b"\n", match.start())
        line = data[match.start(): end if end >= 0 else len(data)]
        if cmd not in allowed:
            bad.append(line[:220].decode("ascii", errors="replace"))
        if cmd == "ANTYPE" and b"RESTART" in line.upper():
            bad.append("ANTYPE RESTART is forbidden")
        # Workbench emits ordinary ET/MAT/TYPE/etc. command chains with '$'.
        # COMMAND matches every chained statement as well as every new line.
        commands[cmd] += 1
    # Source has no conditional/loop/macro blocks; explicitly require that here.
    if any(commands.get(c) for c in ["*IF", "*ENDIF", "*DO", "*ENDDO", "*CREATE", "*END"]):
        bad.append("Unexpected APDL control-flow block")
    if bad:
        raise RuntimeError("Static gate rejected input: " + repr(bad[:20]))
    return dict(commands)


def suffix(study):
    lines = ["", "! Task-owned preprocessor export only; original solve tail removed.",
             "FINISH", "/PREP7", "ALLSEL,ALL", "/GOPR", "/GOLIST",
             "*GET,XNNODE,NODE,0,COUNT", "*GET,XNELEM,ELEM,0,COUNT",
             "*GET,XMATMAX,MAT,0,NUM,MAX", "*GET,XTYPMAX,ETYP,0,NUM,MAX",
             "*CFOPEN,model_counts,txt", "*VWRITE,XNNODE,XNELEM,XMATMAX,XTYPMAX",
             "('NODES=',F16.0,',ELEMENTS=',F16.0,',MAT_MAX=',F8.0,',TYPE_MAX=',F8.0)",
             "*CFCLOS"]
    for number in [170, 174, 175, 184, 185, 186, 187, 188, 189, 154]:
        lines += [f"ESEL,S,ENAME,,{number}", "*GET,XCOUNT,ELEM,0,COUNT",
                  "*CFOPEN,element_family_counts,txt,,APPEND", "*VWRITE,XCOUNT",
                  f"('ENAME_{number}=',F16.0)", "*CFCLOS"]
    for dof in ["UX", "UY", "UZ", "ROTX", "ROTY", "ROTZ"]:
        lines += ["ALLSEL,ALL", f"NSEL,S,D,{dof}", "*GET,XCOUNT,NODE,0,COUNT",
                  "*CFOPEN,constraint_node_counts,txt,,APPEND", "*VWRITE,XCOUNT",
                  f"('{dof}=',F16.0)", "*CFCLOS"]
    lines += ["ALLSEL,ALL", "ETLIST,ALL", "MPLIST,ALL", "DLIST,ALL", "SFELIST,ALL",
              "ALLSEL,ALL", f"CDWRITE,DB,{study}_8000_FE, CDB,,,BLOCKED",
              f"CDWRITE,LOAD,{study}_8000_APPLIED_LOADS,txt",
              "FINISH", "/EXIT,NOSAVE", ""]
    return "\n".join(lines).encode("ascii")


def prepare(study):
    source = SOURCES[study]
    out = HERE / study
    out.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    if data.count(MARKER) != 1:
        raise RuntimeError("Expected exactly one WB SOLVE COMMAND marker")
    before, discarded = data.split(MARKER, 1)
    if re.search(rb"(?mi)^\s*solve\s*(?:!.*)?$", before):
        raise RuntimeError("Unexpected earlier solver command")
    source_commands = gate(before, ALLOWED_SOURCE)
    tail = suffix(study)
    complete = before + tail
    final_commands = gate(complete, ALLOWED_SOURCE | ALLOWED_ADDED)
    target = out / (study + "_preprocess_only.inp")
    target.write_bytes(complete)
    manifest = {
        "study": study, "nominal_total_load_N": 8000,
        "source": str(source), "source_sha256": hashlib.sha256(data).hexdigest(),
        "source_bytes": len(data), "source_prefix_bytes": len(before),
        "source_prefix_sha256": hashlib.sha256(before).hexdigest(),
        "source_prefix_unchanged": complete[:len(before)] == before,
        "removed_tail_bytes": len(discarded) + len(MARKER),
        "input": str(target), "input_sha256": sha(target),
        "static_gate_passed": True, "source_commands": source_commands,
        "generated_commands": final_commands, "solve_commands_present": False,
        "conditional_or_loop_blocks_present": False,
        "external_include_sys_or_delete_present": False,
        "actual_export_runtime": "MAPDL 2026 R1 (261)",
        "actual_2024R2_import_verified": False,
        "purpose": "Existing mesh backup; not original CAD preprocessing tree",
    }
    (out / "static_gate.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return target, manifest


def run(study, target):
    if not EXE.is_file():
        raise FileNotFoundError(EXE)
    out = target.parent
    # Existing ASCII workspace junction avoids a Chinese solver working path.
    ascii_root = Path(r"C:\Users\wangch251\Documents\ChatGPT\ansys_S01_20261013")
    work = ascii_root / out.relative_to(ROOT)
    work.resolve().relative_to(ROOT.resolve())
    args = [str(EXE), "-b", "-smp", "-np", "1", "-dir", str(work),
            "-j", study.lower() + "_fe_export", "-i", target.name,
            "-o", "export.out"]
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    with (out / "launcher.txt").open("wb") as log:
        proc = subprocess.Popen(args, cwd=work, stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    state = {"study": study, "pid": proc.pid, "started_utc": started,
             "args": args, "working_directory": str(work), "status": "running"}
    state_path = out / "run.json"
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    print(json.dumps(state), flush=True)
    while proc.poll() is None:
        time.sleep(2)
    state.update(status="completed", exit_code=proc.returncode,
                 ended_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    cdb = out / (study + "_8000_FE.CDB")
    if not cdb.exists():
        cdb = out / (study + "_8000_FE.cdb")
    if cdb.exists():
        state.update(cdb=str(cdb), cdb_bytes=cdb.stat().st_size, cdb_sha256=sha(cdb))
    error = out / (study.lower() + "_fe_export.err")
    state["err_file_exists"] = error.exists()
    if error.exists():
        state["err_file_text"] = error.read_text(encoding="utf-8", errors="replace")[-16000:]
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in state.items() if k != "err_file_text"}), flush=True)
    return state


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("study", choices=list(SOURCES))
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    target, manifest = prepare(args.study)
    print(json.dumps({"study": args.study, "static_gate_passed": True,
                      "source_prefix_bytes": manifest["source_prefix_bytes"],
                      "input": str(target)}), flush=True)
    if args.run:
        run(args.study, target)
