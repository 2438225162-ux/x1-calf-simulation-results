# S01 / C01：已有有限元网格的前处理备用文件

日期：2026-10-15。此目录与中性 CAD + 原生前处理重建包分开。

本目录的 `S01/S01_8000_FE.CDB` 和 `C01/C01_8000_FE.CDB` 是现有两个 **8000 N 主工况**的 MAPDL Blocked CDB，包含已有节点、单元、材料、连接单元、固定约束和表面载荷。**没有重新求解，也没有结果文件。** 4000 N 对照工况没有再导出；与此前结果一样，目标是审查已有 8000 N 前处理。

这些 CDB 由本机 **MAPDL 2026 R1** 生成。由于本机没有完整的 Mechanical/MAPDL 2024 R2，目前没有声称在 24R2 中实际导入、保存或重开验证成功。

## 在 24R2 中查看的流程

1. 在 2024 R2 Workbench 新建 **External Model**，在 Setup 中选择其中一份 CDB。
2. 明确源文件的单位：长度 **mm**、力 **N**、质量 **Mg/tonne**、时间 **s**、温度 **°C**。源数据的 MAPDL 单位标注为 `/UNITS,MPA`；材料弹性模量是 N/mm²，密度是 tonne/mm³。不能把这些数字直接当 m、kg 制解释。
3. 保持处理模型数据、接触、约束、命名选择等相关导入开关开启，再将 External Model 的 Setup 连接到静力学系统的 Model。材料可按 24R2 External Model 支持方式连接至 Engineering Data。
4. 打开 Mechanical，按下表和各目录内的 `verification.json` 检查节点/单元数、材料、连接和载荷。只审查前处理时无需点击 Solve。确认无缺失、单位正确后，使用 **24R2** 保存工程并按需归档；取消归档结果/求解文件。

## 保留范围和限制

CDB 是有限元模型转移文件。Mechanical 从网格合成几何；它不恢复原 STEP 的 CAD B-rep、CAD 原生关系或原 Mechanical 网格控制树。导入器支持的载荷/接触等对象受 24R2 功能和导入选项限制，不能承诺全部以原名称、原GUI树对象一一复原。想继续改变 CAD 面、修改网格控制或使用清晰的原生接触/关节/螺栓梁对象，请优先使用单独的 **CAD + 原生前处理重建包**。

CDB 已含固定约束和载荷。`*_APPLIED_LOADS.txt` 是审计用的重复导出，**不要额外叠加到已导入的模型上**。CDB 中保留了源数据库字符串参数中的旧路径，它们在这里仅为未使用的元数据；本次静态 gate 禁止外部 include、系统命令和文件删除，源路径没有被拿来读取结果或写回原工程。

当前静力步之外的完整分析控制不一定由 CDWRITE 导出；若后续要在 24R2 求解，应根据原生重建包/工况设置核对控制项。不要把 CDB 导入本身视为跨版本数值复现或工程验收。

## 实际导出计数

| 项目 | S01 | C01 |
|---|---:|---:|
| 节点，含辅助节点 | 1,229,422 | 220,722 |
| 全部单元 | 804,827 | 993,608 |
| 实体单元 | 757,838 SOLID187 | 964,420 SOLID185 |
| 梁单元 | 0 | 8 BEAM188 |
| 关节单元 | 2 MPC184 | 0 |
| TARGE170 | 18,518 | 13,032 |
| CONTA174 | 21,467 | 14,616 |
| 载荷表面 SURF154 | 7,002 | 1,532 |
| 固定节点数，每个节点 UX/UY/UZ | 16,201 | 2,933 |
| MAPDL 错误数 | 0 | 0 |
| MAPDL 警告数 | 119 | 17 |
| 方程求解器时间 | 0.0 s | 0.0 s |

警告来自源前处理控制和对既有网格执行的 CHECK，包括单次平衡迭代提示、MPC184 线性化提示、无实体材料属性的连接/载荷辅助单元，以及四面体形状警告。保留 `.err` 和 `export.out` 如实披露；0 错误不等于网格已经收敛或所有形状质量都合格。

## 完整性证据

- 两份源 `ds.dat` 以 `WB SOLVE COMMAND` 标记之前的完整字节前缀创建新输入，原文件保持只读；后续包含 `SOLVE` 的整段尾部均移除，未残留该段的 `*IF`、`/EOF`、`*ENDIF`。
- whitelist gate 审查所有执行语句，包含 Workbench 的 `$` 命令链；禁止求解、重启动求解、外部 include、系统执行、任意宏执行和删除文件。
- 只在任务专属目录运行隐藏的 MAPDL 批处理：`-b -smp -np 1`。末尾进入 PREP7，选择全部，执行 `CDWRITE,DB,...,BLOCKED`、审计用的 `CDWRITE,LOAD`，最后 `/EXIT,NOSAVE`。
- `static_gate.json`、`run.json`、`verification.json` 记录源/新输入/CDB SHA-256、实际进程与运行时、节点/单元计数、材料值和载荷/约束核对。
- 校验器按实际 ETBLOCK、NBLOCK、EBLOCK、DBLOCK、SFEBLOCK 读取；CDB 中约束和表面载荷块与单独 LOAD 导出的块一致。压力文本精度按相对误差 1e-8 核对原输入；不改写 CDB 的原始字节或版本标签。

## 官方资料

- [2024 R2 External Model 支持与限制](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/wb2_help/wb2h_ModelLoadapp.html)
- [2024 R2 CDWRITE：DB、Blocked、当前载荷步及限制](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/ans_cmd/Hlp_C_CDWRITE.html)
- [2024 R2 CDB Blocked 格式](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/ans_prog/Hlp_P_INT3_3.html)
- [2024 R2 /UNITS：MPA 单位体系](https://ansyshelp.ansys.com/public/Views/Secured/corp/v242/en/ans_cmd/Hlp_C_UNITS.html)
