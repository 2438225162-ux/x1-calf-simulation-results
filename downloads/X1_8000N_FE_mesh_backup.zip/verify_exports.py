"""Read-only structural/data checks on exported blocked CDB files."""
from __future__ import annotations
import collections
import hashlib
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
NUM = rb"[+\-0-9.EeDd]+"


def floats(value):
    return float(value.strip().replace(b"D", b"E").replace(b"d", b"e"))


def command_map(data, command):
    pattern = rb"(?mi)(?:^[ \t]*|(?<=\$)[ \t]*)" + command + rb"\s*,([^\r\n$!]*)"
    return [m.group(1).strip().split(b",") for m in re.finditer(pattern, data)]


def source_et_map(data):
    variables = {}
    result = {}
    pattern = rb"(?mi)(?:^[ \t]*|(?<=\$)[ \t]*)(ET|\*SET)\s*,([^\n$!]*)"
    for match in re.finditer(pattern, data):
        command, args = match.groups()
        row = [x.strip().upper() for x in args.split(b",")]
        if command.upper() == b"*SET":
            try:
                variables[row[0]] = floats(row[1])
            except (ValueError, IndexError):
                pass
        else:
            ident = int(variables[row[0]]) if row[0] in variables else int(row[0])
            result[ident] = int(row[1])
    return result


def blocked_et_map(data):
    header = re.search(rb"(?mi)^ETBLOCK\s*,\s*(\d+),\s*(\d+)\s*\n", data)
    assert header
    lines = data[header.end():header.end() + 25000].splitlines()
    count = int(header.group(2))
    rows = [line.split() for line in lines[1:count + 1]]
    assert len(rows) == count
    return {int(row[0]): int(row[1]) for row in rows}


def load_block(data, name):
    start = re.search(rb"(?mi)^" + name + rb"\s*,", data)
    if not start:
        raise AssertionError("Missing " + name.decode())
    if name == b"DBLOCK":
        end = re.search(rb"(?m)^\s*-1\s*\r?$", data[start.end():])
        assert end
        return data[start.start():start.end() + end.end()].replace(b"\r\n", b"\n").rstrip()
    end = re.search(rb"(?mi)^SFE\s*,end[^\r\n]*", data[start.end():])
    assert end
    return data[start.start():start.end() + end.end()].replace(b"\r\n", b"\n").rstrip()


def verify(study):
    out = HERE / study
    gate = json.loads((out / "static_gate.json").read_text(encoding="utf-8"))
    run = json.loads((out / "run.json").read_text(encoding="utf-8"))
    assert gate["static_gate_passed"] and not gate["solve_commands_present"]
    assert run["exit_code"] == 0
    cdb_path = Path(run["cdb"])
    cdb_raw = cdb_path.read_bytes()
    source = Path(gate["source"]).read_bytes()[:gate["source_prefix_bytes"]]
    loads = (out / (study + "_8000_APPLIED_LOADS.txt")).read_bytes()
    log = (out / "export.out").read_bytes()
    assert hashlib.sha256(cdb_raw).hexdigest() == run["cdb_sha256"]
    assert hashlib.sha256(source).hexdigest() == gate["source_prefix_sha256"]
    # This Windows MAPDL build writes CR-CR-LF in its exported text files.
    # Preserve original bytes/hashes; normalize line endings only for parsing.
    cdb = cdb_raw.replace(b"\r", b"")
    loads = loads.replace(b"\r", b"")
    source = source.replace(b"\r", b"")
    counts = {k: int(float(v)) for k, v in re.findall(
        r"(NODES|ELEMENTS|MAT_MAX|TYPE_MAX)=\s*([0-9.]+)",
        (out / "model_counts.txt").read_text())}
    families = {int(k): int(float(v)) for k, v in re.findall(
        r"ENAME_(\d+)=\s*([0-9.]+)", (out / "element_family_counts.txt").read_text())}
    dofs = {k: int(float(v)) for k, v in re.findall(
        r"(UX|UY|UZ|ROTX|ROTY|ROTZ)=\s*([0-9.]+)",
        (out / "constraint_node_counts.txt").read_text())}
    node_header = re.search(rb"(?mi)^NBLOCK,6,SOLID,\s*(\d+),\s*(\d+)", cdb)
    elem_header = re.search(rb"(?mi)^EBLOCK,19,SOLID,\s*(\d+),\s*(\d+)", cdb)
    assert node_header and elem_header
    assert int(node_header.group(2)) == counts["NODES"]
    assert int(elem_header.group(2)) == counts["ELEMENTS"]
    assert sum(families.values()) == counts["ELEMENTS"]

    et_source = source_et_map(source)
    et_cdb = blocked_et_map(cdb)
    assert et_source == et_cdb, "Element type map changed"

    wanted = {b"EX", b"EY", b"EZ", b"NUXY", b"NUYZ", b"NUXZ", b"DENS", b"GXY", b"GYZ", b"GXZ"}
    mp_source = {(row[0].strip().upper().decode(), int(row[1])): floats(row[2])
                 for row in command_map(source, b"MP") if row[0].strip().upper() in wanted}
    mp_cdb = {(row[2].strip().upper().decode(), int(row[3])): floats(row[5])
              for row in command_map(cdb, b"MPDATA") if row[2].strip().upper() in wanted}
    assert mp_source.keys() == mp_cdb.keys(), "Material key map changed"
    for key in mp_source:
        assert math.isclose(mp_source[key], mp_cdb[key], rel_tol=1e-9, abs_tol=1e-18), key

    db = load_block(cdb, b"DBLOCK")
    assert db == load_block(loads, b"DBLOCK"), "Constraint blocks differ"
    dbc = int(db.splitlines()[0].split(b",")[1])
    constraints = collections.Counter()
    for line in db.splitlines()[2:-1]:
        row = line.split()
        constraints[row[1].decode()] += 1
        assert float(row[2]) == 0 and float(row[3]) == 0
    assert sum(constraints.values()) == dbc == sum(dofs.values())
    for key, value in constraints.items():
        assert value == dofs[key]

    sfe = load_block(cdb, b"SFEBLOCK")
    assert sfe == load_block(loads, b"SFEBLOCK"), "Surface load blocks differ"
    pressure_elements = set()
    nonzero_pressure_values = set()
    for line in sfe.splitlines()[2:-1]:
        row = line.split()
        if len(row) < 4:
            continue
        values = [floats(v) for v in row[3:]]
        nonzero = [v for v in values if v != 0]
        if nonzero:
            assert int(row[1]) == 2 and int(row[2]) == 1
            pressure_elements.add(int(row[0]))
            nonzero_pressure_values.update(nonzero)
    assert len(pressure_elements) == families[154]
    source_pressures = {floats(row[4]) for row in command_map(source, b"SFE")
                        if row[1].strip() == b"2" and row[4].strip() != b"0."}
    assert len(source_pressures) == len(nonzero_pressure_values) == 1
    assert math.isclose(next(iter(source_pressures)), next(iter(nonzero_pressure_values)), rel_tol=1e-8)

    error_count = int(re.search(rb"NUMBER OF ERROR\s+MESSAGES ENCOUNTERED=\s*(\d+)", log).group(1))
    warning_count = int(re.search(rb"NUMBER OF WARNING MESSAGES ENCOUNTERED=\s*(\d+)", log).group(1))
    solve_seconds = floats(re.search(rb"Elapsed time in equation solver\s*:\s*(" + NUM + rb")", log).group(1))
    assert error_count == 0 and solve_seconds == 0
    forbidden_cdb = re.findall(rb"(?mi)^\s*(SOLVE|LSOLVE|LSSOLVE|MFSOLVE|/SYS|/INPUT|/DELETE|\*USE)\s*(?:,|\r?$)", cdb)
    assert not forbidden_cdb
    result = {
        "study": study, "passed": True, "export_runtime": "MAPDL 2026 R1",
        "actual_2024R2_import_verified": False, "results_present": False,
        "nodes": counts["NODES"], "elements": counts["ELEMENTS"],
        "element_family_counts": families, "element_type_definitions": len(et_cdb),
        "element_type_mapping_matches_source": True,
        "linear_elastic_density_material_values_checked": len(mp_source),
        "material_values_match_source": True,
        "material_values": [{"label": k[0], "material_id": k[1], "value": v}
                            for k, v in sorted(mp_cdb.items())],
        "constraint_nodes_by_dof": dofs, "constraint_records": dbc,
        "constraint_block_identical_in_cdb_and_load_export": True,
        "nonzero_pressure_elements": len(pressure_elements),
        "source_pressure_N_per_mm2": sorted(source_pressures),
        "exported_pressure_N_per_mm2": sorted(nonzero_pressure_values),
        "pressure_numeric_relative_tolerance": 1e-8,
        "surface_load_block_identical_in_cdb_and_load_export": True,
        "load_block_sha256": hashlib.sha256(sfe).hexdigest(),
        "constraint_block_sha256": hashlib.sha256(db).hexdigest(),
        "mapdl_errors": error_count, "mapdl_warnings": warning_count,
        "equation_solver_elapsed_seconds": solve_seconds,
        "source_prefix_unchanged": True, "static_no_solve_gate_passed": True,
        "cdb_bytes": len(cdb_raw), "cdb_sha256": run["cdb_sha256"],
        "cdb_node_header_count_matches_runtime": True,
        "cdb_element_header_count_matches_runtime": True,
        "all_element_family_counts_sum_to_runtime_element_count": True,
    }
    (out / "verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "material_values"}), flush=True)
    return result


if __name__ == "__main__":
    results = [verify(study) for study in ["S01", "C01"]]
    (HERE / "verification.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
